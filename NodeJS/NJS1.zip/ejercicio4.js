const calculos = require('./calculos');

console.log("La suma de 4+5 es ",sumar(4,5));
console.log("La resta de 8-6 es ",restar(8,6));
console.log("La division de 30/5 es ",dividir(30,5));
console.log("La multiplicacion de 3x11 es ",multiplicar(3,11));