function sumar(a,b)
{
    return a+b;
}
function restar(a,b)
{
    return a-b;
}
function dividir(a,b)
{
    return a/b;
}   
function multiplicar(a,b)
{
    return a*b;
}
console.log("la suma de 4+5 es ",sumar(4,5));
console.log("la resta de 3-6 es ",restar(3,6));
console.log("la division de 20/4 es ",dividir(20,4));
console.log("la multiplicacion de 2x7 es ",multiplicar(2,7));