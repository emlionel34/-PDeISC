function contarHijos() {
  const contenedor = document.getElementById('contenedor');
  const cantidad = contenedor.children.length;
  document.getElementById('resultado').textContent = 'Cantidad de hijos: ' + cantidad;
}
