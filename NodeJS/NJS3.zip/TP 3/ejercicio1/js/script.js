let h1 = null;
let img = null;

function agregarH1() {
  if (!h1) {
    h1 = document.createElement('h1');
    h1.textContent = 'Hola DOM';
    document.getElementById('contenedor').appendChild(h1);
  }
}

function cambiarTextoH1() {
  if (h1) h1.textContent = 'Chau DOM';
}

function cambiarColorH1() {
  if (h1) h1.style.color = 'red';
}

function agregarImagen() {
  if (!img) {
    img = document.createElement('img');
    img.src = 'img/imagen1.png';
    img.alt = 'Imagen DOM';
    img.style.width = '200px';
    document.getElementById('contenedor').appendChild(img);
  }
}

function cambiarImagen() {
  if (img) {
    img.src = 'img/imagen2.png';
  }
}

function cambiarTamanoImagen() {
  if (img) {
    img.style.width = '400px';
  }
}
