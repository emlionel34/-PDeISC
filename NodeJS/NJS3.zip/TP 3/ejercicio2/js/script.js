function mostrarComponente(id) {
  const componentes = document.querySelectorAll('.componente');
  componentes.forEach(comp => comp.style.display = 'none');
  document.getElementById(id).style.display = 'block';
}

function cambiarFondo(elemento) {
  elemento.style.backgroundColor = 'yellow';
}

function mostrarTecla(event) {
  document.getElementById('teclaPresionada').textContent = 'Tecla: ' + event.key;
}

function cambiarColorFondo() {
  const color = document.getElementById('color').value;
  document.body.style.backgroundColor = color;
}

let contador = 0;
function sumarClick() {
  contador++;
  document.getElementById('contador').textContent = 'Clicks: ' + contador;
}

function ocultarElemento(elemento) {
  elemento.style.display = 'none';
}
