let enlacesCreados = false;

function crearEnlaces() {
  if (enlacesCreados) return;
  const contenedor = document.getElementById('contenedor');
  for (let i = 1; i <= 5; i++) {
    const a = document.createElement('a');
    a.href = 'https://www.google.com';
    a.target = '_blank';
    a.textContent = 'Enlace ' + i;
    a.id = 'link' + i;
    contenedor.appendChild(a);
  }
  enlacesCreados = true;
}

function modificarEnlaces() {
  const log = document.getElementById('log');
  log.innerHTML = '';
  for (let i = 1; i <= 5; i++) {
    const a = document.getElementById('link' + i);
    if (a) {
      const oldHref = a.href;
      a.href = 'https://www.wikipedia.org';
      log.innerHTML += `Enlace ${i} cambiado: ${oldHref} → ${a.href}<br>`;
    }
  }
}
