function agregarParrafo() {
    const contenido = document.getElementById('contenido');
    contenido.innerHTML = "<p>parrafo añadido</p>";
  }
  
  function agregarLista() {
    const contenido = document.getElementById('contenido');
    contenido.innerHTML = `
      <ul>
        <li>Elemento de la lista 1</li>
        <li>Elemento de la lista 2</li>
        <li>Elemento de la lista 3</li>
      </ul>
    `;
  }
  
  function agregarTabla() {
    const contenido = document.getElementById('contenido');
    contenido.innerHTML = `
      <table>
        <tr>
          <th>Nombre</th>
          <th>Edad</th>
        </tr>
        <tr>
          <td>Juan</td>
          <td>28</td>
        </tr>
        <tr>
          <td>Ana</td>
          <td>24</td>
        </tr>
      </table>
    `;
  }
  
  function agregarImagen() {
    const contenido = document.getElementById('contenido');
    contenido.innerHTML = `
      <img src="https://via.placeholder.com/150" alt="Imagen añadida dinámicamente">
    `;
  }
  