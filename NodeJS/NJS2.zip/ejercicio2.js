console.log("La suma de 4+5 es ",4+5);
console.log("La resta de 3-6 es ",3-6);
console.log("La multiplicacion de 2x7 es ",2*7);
console.log("La division de 20/4 es ",20/4);